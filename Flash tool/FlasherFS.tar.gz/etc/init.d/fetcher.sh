echo "****************************************************"
echo "****************************************************"
echo ""
echo "Sitara Flash Fetcher Script - 07/28/2014"
echo ""

## Bring up the USB interface. CPSW Ethernet is automatically brought up
## by init scripts.
ifup usb0

## Set Server IP here. This commande depends on a default gateway
## being set in the server. In Linux isc-dhcp-server, this is
## done with the routers option in /etc/dhcp/dhcpd.conf. In Uniflash,
## this is done in the open-dhcp config file. This address is 
## usually set to the same address as the server to make it
## the default gateway.
SERVER_IP="192.168.100.1"
##SERVER_IP=$(route -n | grep 'UG[ \t]' | awk '{print $2}')

## If server IP is not set correctly, or can't be discovered with 
## with the above command, set it to a defined default.
##if [ ${SERVER_IP} == "" ]
##	then SERVER_IP="192.168.100.1"
##fi

## Set the name of the debrick script to be fetched.
DEBRICK_SCRIPT="debrick.sh"

## TFTP Customized flasher script from server
echo "Getting flasher script from server: ${SERVER_IP}"
tftp -g -r ${DEBRICK_SCRIPT} ${SERVER_IP}

## Test to make sure that debrick could be downloaded. Exit if not.
if [ $? -ne 0 ]
	then 
		echo "Unable to fetch debrick script! Exiting..."
		exit 1
fi

## Make the debrick script executable
chmod +x ${DEBRICK_SCRIPT}

## Test to make sure that debrick could be downloaded. Exit if not.
if [ $? -ne 0 ]
	then 
		echo "Unable to make debrick script executable. Exiting..."
		exit 1
fi

echo ""
echo "********************************************"
echo "Sitara Flash Fetcher is complete. Executing ${DEBRICK_SCRIPT}."
echo ""

## Execute script. Pass SERVER_IP to debrick.sh.
echo "Calling Script=${DEBRICK_SCRIPT} with SERVER_IP=${SERVER_IP}"
./${DEBRICK_SCRIPT} 



